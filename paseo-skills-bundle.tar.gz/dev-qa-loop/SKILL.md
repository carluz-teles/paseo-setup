---
name: dev-qa-loop
description: Run the global Dev + QA agent pair in a Paseo loop on the current workspace. Use when the user says "dev-qa", "roda o loop dev/qa", or wants a task implemented by the dev agent and verified by the QA agent until done.
user-invocable: true
---

# Dev + QA Loop

Launches the user's two global agents as a Paseo worker/verifier loop: the **Dev agent** implements, the **QA agent** verifies. The loop repeats until QA approves or limits are hit.

**User's task:** $ARGUMENTS

## Prerequisites

1. Read the **paseo** skill (CLI surface) and `~/.paseo/orchestration-preferences.json` (actual file read — it defines both agents: `impl` = Dev, `audit` = QA, plus behavior preferences to weave into the prompts).
2. Discover objective checks for this workspace by detecting the stack at the repo root — no per-repo config required:
   - `go.mod` → `go build ./...` and `go test ./...`
   - `package.json` → use its `scripts` (lint/test/build) with the right package manager (`pnpm-lock.yaml` → pnpm, `package-lock.json` → npm, `yarn.lock` → yarn)
   - `pyproject.toml` → `pytest` (or the project's configured runner)
   - If a `paseo.json` with a `scripts` map exists, prefer those commands.

## Build the loop

- **Worker (Dev) prompt** — self-contained: the user's task, the repo, acceptance criteria, and the Dev-agent preferences from the preferences file. Explicit about what counts as progress this iteration.
- **Verifier (QA) prompt** — the QA-agent preferences: check facts, run the project checks, cite commands and output, never fix code, `done=true` only when acceptance criteria are objectively met.
- **Shell checks** — add `--verify-check` for each objective command available in this workspace (from `paseo.json` scripts or the repo's standard commands, e.g. `go test ./...`, `npm run lint`).
- **Providers** — worker from `providers.impl`, verifier from `providers.audit`. Never hardcode.
- **Limits** — default `--max-iterations 8 --max-time 2h` unless the user says otherwise. Use `--archive` so each iteration's agents can be inspected.

## Launch

```bash
paseo loop run "<worker prompt>" \
  --provider <impl> \
  --verify-provider <audit> \
  --verify "<verifier prompt>" \
  --verify-check "<objective check>" \
  --max-iterations 8 --max-time 2h --archive \
  --name "dev-qa: <short task name>"
```

Then report the loop id and how to follow it: `paseo loop logs <id>`, `paseo loop inspect <id>`, `paseo loop stop <id>`.
