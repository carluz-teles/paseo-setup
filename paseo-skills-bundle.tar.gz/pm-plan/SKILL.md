---
name: pm-plan
description: Run the global PM agent to analyze a ticket/task from a product perspective before implementation. Use when the user says "pm", "analisa o ticket", "planeja a task", "roda o pm", or wants requirements analysis, product questions, and acceptance criteria before the dev-qa loop.
user-invocable: true
---

# PM Plan

Spawns the user's global **PM agent** to analyze a ticket before any code is written. Output: a self-contained brief with measurable acceptance criteria, ready to feed `/dev-qa-loop`.

**Ticket/task:** $ARGUMENTS

## Prerequisites

Read the **paseo** skill and `~/.paseo/orchestration-preferences.json` (actual file read). The PM uses the `planning` provider; weave the PM-agent preferences into its prompt. Never hardcode a provider.

## Flow

1. **Spawn the PM agent** in the current workspace (`create_agent` with the `planning` provider, or `paseo run` from the CLI). Its prompt must include the ticket verbatim plus the PM preferences, and instruct it to produce:
   - Restated goal and user value (what problem, for whom)
   - Affected user flows and touchpoints in this product
   - Edge cases and product risks (billing, auth, data loss, i18n, mobile)
   - **Open questions** — only those whose answer changes scope, max 5, prioritized, each with the PM's recommended default answer
   - **Draft acceptance criteria** — objectively testable statements
   The PM is read-only: it may explore the repo to ground its analysis but must not modify files.
2. **Relay the open questions to the user** with the PM's recommended defaults. Wait for answers — do not proceed on defaults without showing them first.
3. **Send the answers back** to the PM agent (`send_agent_prompt`). It produces the final brief: goal, scope in/out, decisions taken, final acceptance criteria, constraints.
4. **PM + Dev describe the implementation plan together.** Spawn a Dev planner (the `impl` provider, read-only) with the PM's brief: it explores the codebase and drafts the implementation plan — files to touch, approach, test plan (which tests capture each acceptance criterion, to be written FIRST), risks. Send the draft back to the PM agent for product review (scope creep, missed criteria); incorporate its notes into one unified plan.
5. **Present the unified plan to the user for approval.** Wait — the loop does not start without it. Apply any adjustments the user asks for.
6. **On approval, launch `/dev-qa-loop`** with brief + plan as the worker task. TDD dynamics inside the loop: Dev writes the failing tests from the acceptance criteria first, then implements; QA runs the tests and checks each iteration — failures send the Dev into another iteration until everything passes.

## PM prompt rules

Product-first, not solution-first: user value, flows, and risks before technical design. Questions are expensive — ask only what materially changes scope. Every acceptance criterion must be verifiable by a test or an objective command.
