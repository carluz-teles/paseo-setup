---
name: code-review-loop
description: Run the global Code Reviewer agent in review rounds against the Dev agent. Use when the user says "code review", "roda o review", "revisa o código", or after a dev-qa loop passes and the diff needs review before commit.
user-invocable: true
---

# Code Review Loop

Runs the user's global **Code Reviewer agent** in rounds against the **Dev agent** until the diff has zero blocking findings. Use after the feature is "done" (dev-qa loop passed) and before commit.

**User's arguments:** $ARGUMENTS

## Prerequisites

Read the **paseo** skill and `~/.paseo/orchestration-preferences.json` (actual file read — Reviewer = `review` provider, Dev = `impl` provider, plus both personas). Never hardcode providers.

## Scope

The diff under review is the working tree changes (`git diff` + relevant untracked files), or the range/files the user names in `$ARGUMENTS`. State the scope in both prompts.

## The round mechanic

Reviewer and Dev interact through `CODE_REVIEW.md` at the repo root, driven by `paseo loop run`:

- **Verifier (Reviewer, `review` provider)** — reviews the full diff each round: correctness bugs, security, project conventions, idiomatic patterns (the installed language/framework skills are the ruler), unjustified complexity. Writes findings marked `BLOCKING` (with file:line and why) to `CODE_REVIEW.md`; `ADVISORY` suggestions go only in the verdict text. Returns done=false while blocking findings exist. On approval (zero blocking), deletes `CODE_REVIEW.md` and lists the advisory notes in the verdict. Never fixes code.
- **Worker (Dev, `impl` provider)** — reads `CODE_REVIEW.md`; if it exists, addresses every BLOCKING finding and marks each resolved in the file (what changed, where). If absent, this is round 1: makes no changes and just summarizes the diff under review. Must keep the project checks green.

## Launch

```bash
paseo loop run "<worker prompt>" \
  --provider <impl> \
  --verify-provider <review> \
  --verify "<reviewer prompt>" \
  --verify-check "<project test command>" \
  --max-iterations 4 --max-time 1h \
  --name "code-review: <short scope>"
```

Include the project's test/lint commands as `--verify-check` so review fixes never regress the dev-qa result.

## Report

When the loop ends: number of rounds, blocking findings raised and how each was resolved, and the advisory list (user decides on those). If `max-iterations` was hit with blocking findings still open, say so explicitly and point to `CODE_REVIEW.md`.
